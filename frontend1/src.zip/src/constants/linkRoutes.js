export const baseURL = "http://localhost:5000";
export const sendMessageRoute = `${baseURL}/api/messages/addmsg`;
export const getMessagesRoute = `${baseURL}/api/messages/getmsg`;
