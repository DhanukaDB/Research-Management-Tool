import './chat.css';
import React from 'react'

export default function Chat() {
    return (
        <div>
            Chat
        </div>
    )
}
